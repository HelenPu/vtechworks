/**
 * The contents of this file are subject to the license and copyright
 * detailed in the LICENSE and NOTICE files at the root of the source
 * tree and available online at
 *
 * http://www.dspace.org/license/
 */
package org.dspace.app.sherpa;

import org.apache.http.HttpStatus;
import org.apache.http.config.SocketConfig;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.commons.lang.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.log4j.Logger;
import org.dspace.core.ConfigurationManager;

public class SHERPAService
{
    private CloseableHttpClient client = null;

    private int maxNumberOfTries;
    private long sleepBetweenTimeouts;
    private int timeout;

    /** log4j category */
    private static final Logger log = Logger.getLogger(SHERPAService.class);

    public SHERPAService() {
        HttpClientBuilder custom = HttpClients.custom();
        // httpclient 4.3+ doesn't appear to have any sensible defaults any more. Setting conservative defaults as not to hammer the SHERPA service too much.
        client=custom.disableAutomaticRetries().setMaxConnTotal(5).setDefaultSocketConfig(SocketConfig.custom().setSoTimeout(timeout).build()).build();

    }


    public SHERPAResponse searchByJournalISSN(String query)
    {
        String endpoint = ConfigurationManager.getProperty("sherpa.romeo.url");
        String apiKey = ConfigurationManager.getProperty("sherpa.romeo.apikey");

        HttpGet method = null;
        SHERPAResponse sherpaResponse = null;
        int numberOfTries = 0;

        while(numberOfTries<maxNumberOfTries && sherpaResponse==null) {
            numberOfTries++;

            try {
                Thread.sleep(sleepBetweenTimeouts * (numberOfTries-1));

                URIBuilder uriBuilder = new URIBuilder(endpoint);
                uriBuilder.addParameter("issn", query);
                uriBuilder.addParameter("versions", "all");
                if (StringUtils.isNotBlank(apiKey))
                    uriBuilder.addParameter("ak", apiKey);

                method = new HttpGet(uriBuilder.build());

                // Execute the method.

                HttpResponse response = client.execute(method);
                int statusCode = response.getStatusLine().getStatusCode();

                if (statusCode != HttpStatus.SC_OK) {
                    sherpaResponse = new SHERPAResponse("SHERPA/RoMEO return not OK status: "
                            + statusCode);
                }

                HttpEntity responseBody = response.getEntity();

                if (null != responseBody)
                    sherpaResponse = new SHERPAResponse(responseBody.getContent());
                else
                    sherpaResponse = new SHERPAResponse("SHERPA/RoMEO returned no response");
            } catch (Exception e) {
                log.error(e.getMessage(),e);
            }
        }

        if(sherpaResponse==null){
            sherpaResponse = new SHERPAResponse(
                    "Error processing the SHERPA/RoMEO answer");
        }

        return sherpaResponse;
    }

    public void setMaxNumberOfTries(int maxNumberOfTries) {
        this.maxNumberOfTries = maxNumberOfTries;
    }

    public void setSleepBetweenTimeouts(long sleepBetweenTimeouts) {
        this.sleepBetweenTimeouts = sleepBetweenTimeouts;
    }

    public void setTimeout(int timeout) {
        this.timeout = timeout;
    }
}
